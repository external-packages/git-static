package TimeDate;

use vars qw($VERSION);

$VERSION = "1.21";

=pod

This is an empty module which is just there to get ownership on TimeDate
using first-come permissions from PAUSE.

This was required during the release of 1.21 for transferring ownership.

=cut

1;
