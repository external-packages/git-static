package LWP::DebugFile;

our $VERSION = '6.55';

# legacy stub

1;
